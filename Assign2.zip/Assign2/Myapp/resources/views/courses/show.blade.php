@extends('layouts.master')

@section('title', 'Course Details')

@section('content')

@if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif



<div class="container">
    <!-- Display the Course Name and Code -->
    <div class="card mt-4">
        <div class="card-body">
            <h2 class="card-title">Course: {{ $course->course_name }} <small class="text-muted">({{ $course->course_code }})</small></h2>
        </div>
    </div>

    <!-- Display Teachers -->
    <div class="card mt-4">
        <div class="card-header">
            <h3>Teachers</h3>
        </div>
        <div class="card-body">
            @if ($teachers && $teachers->isEmpty())
                <p class="text-muted">No teachers are assigned to this course.</p>
            @else
                <ul class="list-group">
                    @foreach ($teachers as $teacher)
                        <li class="list-group-item">
                            <strong>{{ $teacher->name }}</strong> <span class="text-muted">({{ $teacher->email }})</span>
                        </li>
                    @endforeach
                </ul>
            @endif
        </div>
    </div>

    <!-- JavaScript to show or hide the forms -->
    <script>
        function showEditForm(assessmentId) {
            document.getElementById('editAssessmentForm_' + assessmentId).style.display = 'block';
        }

        function hideEditForm(assessmentId) {
            document.getElementById('editAssessmentForm_' + assessmentId).style.display = 'none';
        }

        function showAddAssessmentForm() {
            document.getElementById('addAssessmentForm').style.display = 'block';
            document.getElementById('addAssessmentButton').style.display = 'none';
        }

        function hideAddAssessmentForm() {
            document.getElementById('addAssessmentForm').style.display = 'none';
            document.getElementById('addAssessmentButton').style.display = 'block';
        }
    </script>

 <!-- Display Assessments -->
<h3>Assessments</h3>
@if ($course->assessments && !$course->assessments->isEmpty())
    <ul>
        @foreach ($course->assessments as $assessment)
            <li>
                <!-- Check if the user is authenticated and is a teacher -->
                @if(auth()->check() && auth()->user()->is_teacher)
                    <!-- Teacher-specific link -->
                    <a href="{{ route('teacher.assessment.show', $assessment->id) }}">
                        {{ $assessment->assessment_title }} - 
                        Due: {{ $assessment->due_date->format('d M Y') }} at {{ $assessment->time }}
                    </a>

                    <!-- Display Edit Link for Teachers Only if Authenticated -->
                    <a href="#" id="editAssessmentLink_{{ $assessment->id }}" class="ms-3 text-primary" onclick="event.preventDefault(); showEditForm({{ $assessment->id }});">Edit</a>

                @elseif(auth()->check() && !auth()->user()->is_teacher)
                    <!-- Student-specific link -->
                    <a href="{{ route('student.assessment.show', $assessment->id) }}">
                        {{ $assessment->assessment_title }} - 
                        Due: {{ $assessment->due_date->format('d M Y') }} at {{ $assessment->time }}
                    </a>
                @endif

                <!-- Edit Form for Each Assessment (Hidden by Default) -->
                @if(auth()->check() && auth()->user()->is_teacher)
                    <div id="editAssessmentForm_{{ $assessment->id }}" class="card mt-3" style="display: none;">
                        <div class="card-header">
                            <h4>Edit Assessment: {{ $assessment->assessment_title }}</h4>
                        </div>
                        <div class="card-body">
                            <form action="{{ route('assessments.update', $assessment->id) }}" method="POST">
                                @csrf
                                @method('PUT')

                                <!-- Assessment Title -->
                                <div class="mb-3">
                                    <label for="assessment_title_{{ $assessment->id }}" class="form-label">Assessment Title (Max 20 characters)</label>
                                    <input type="text" name="assessment_title" id="assessment_title_{{ $assessment->id }}" class="form-control" maxlength="20" value="{{ old('assessment_title', $assessment->assessment_title) }}" >
                                </div>

                                <!-- Instruction -->
                                <div class="mb-3">
                                    <label for="instruction_{{ $assessment->id }}" class="form-label">Instruction</label>
                                    <textarea name="instruction" id="instruction_{{ $assessment->id }}" class="form-control" rows="3" >{{ old('instruction', $assessment->instruction) }}</textarea>
                                </div>

                                <!-- Number of Reviews Required -->
                                <div class="mb-3">
                                    <label for="required_review_{{ $assessment->id }}" class="form-label">Number of Reviews Required</label>
                                    <input type="number" name="required_review" id="required_review_{{ $assessment->id }}" class="form-control" min="1" value="{{ old('required_review', $assessment->required_review) }}" >
                                </div>

                                <!-- Maximum Score -->
                                <div class="mb-3">
                                    <label for="max_score_{{ $assessment->id }}" class="form-label">Maximum Score (1 to 100)</label>
                                    <input type="number" name="max_score" id="max_score_{{ $assessment->id }}" class="form-control" min="1" max="100" value="{{ old('max_score', $assessment->max_score) }}" >
                                </div>

                                <!-- Due Date -->
                                <div class="mb-3">
                                    <label for="due_date_{{ $assessment->id }}" class="form-label">Due Date</label>
                                    <input type="date" name="due_date" id="due_date_{{ $assessment->id }}" class="form-control" value="{{ old('due_date', $assessment->due_date->format('Y-m-d')) }}" >
                                </div>

                                <!-- Due Time -->
                                <div class="mb-3">
                                    <label for="time_{{ $assessment->id }}" class="form-label">Due Time</label>
                                    <input type="time" name="time" id="time_{{ $assessment->id }}" class="form-control" value="{{ old('time', $assessment->time) }}" >
                                </div>

                                <!-- Assessment Type -->
                                <div class="mb-3">
                                    <label for="type_{{ $assessment->id }}" class="form-label">Assessment Type</label>
                                    <select name="type" id="type_{{ $assessment->id }}" class="form-select" >
                                        <option value="student-select" {{ old('type', $assessment->type) === 'student-select' ? 'selected' : '' }}>Student Select</option>
                                        <option value="teacher-assign" {{ old('type', $assessment->type) === 'teacher-assign' ? 'selected' : '' }}>Teacher Assign</option>
                                    </select>
                                </div>

                                <button type="submit" class="btn btn-success">Update Assessment</button>
                                <button type="button" class="btn btn-secondary" onclick="hideEditForm({{ $assessment->id }});">Cancel</button>
                            </form>
                        </div>
                    </div>
                @endif
            </li>
        @endforeach
    </ul>
@endif
    </div>
    @if(auth()->check() && auth()->user()->is_teacher)
        <!-- Button to show the Add Assessment Form -->
        <div class="mt-4">
            <button id="addAssessmentButton" class="btn btn-primary" onclick="showAddAssessmentForm()">Add New Assessment</button>
        </div>
        
        <!-- Form to add a peer review assessment -->
        <div id="addAssessmentForm" class="card mt-4" style="display: none;">
            <div class="card-header">
                <h3>Add Peer Review Assessment</h3>
            </div>
            <div class="card-body">
                <form action="{{ route('assessments.store', $course->id) }}" method="POST">
                    @csrf
                    <div class="mb-3">
                        <label for="assessment_title" class="form-label">Assessment Title (Max 20 characters)</label>
                        <input type="text" name="assessment_title" id="assessment_title" class="form-control"  >
                    </div>

                    <div class="mb-3">
                        <label for="instruction" class="form-label">Instruction</label>
                        <textarea name="instruction" id="instruction" class="form-control" rows="3" ></textarea>
                    </div>

                    <div class="mb-3">
                        <label for="required_review" class="form-label">Number of Reviews Required</label>
                        <input type="number" name="required_review" id="required_review" class="form-control" min="1" value="1" >
                    </div>

                    <div class="mb-3">
                        <label for="max_score" class="form-label">Maximum Score (1 to 100)</label>
                        <input type="number" name="max_score" id="max_score" class="form-control" min="1" max="100" value="100" >
                    </div>

                    <div class="mb-3">
                        <label for="due_date" class="form-label">Due Date</label>
                        <input type="date" name="due_date" id="due_date" class="form-control" >
                    </div>

                    <div class="mb-3">
                        <label for="time" class="form-label">Due Time</label>
                        <input type="time" name="time" id="time" class="form-control" >
                    </div>

                    <div class="mb-3">
                        <label for="type" class="form-label">Assessment Type</label>
                        <select name="type" id="type" class="form-select" >
                            <option value="student-select">Student Select</option>
                            <option value="teacher-assign">Teacher Assign</option>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-primary">Create Assessment</button>
                </form>
            </div>
        </div>

        <!-- Enrollment Form for Teachers -->
        <div class="card mt-4">
            <div class="card-header">
                <h3>Enroll a Student</h3>
            </div>
            
            <div class="card-body">
                @if ($students->isEmpty())
                    <p class="text-muted">All students are already enrolled in this course.</p>
                @else
                    <form action="{{ route('courses.enroll', $course->id) }}" method="POST">
                        @csrf
                        <div class="mb-3">
                            <label for="student_id" class="form-label">Select a Student</label>
                            <select name="student_id" id="student_id" class="form-select" >
                                <option value="">-- Select a Student --</option>
                                @foreach ($students as $student)
                                    <option value="{{ $student->id }}">{{ $student->name }} ({{ $student->email }})</option>
                                @endforeach
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Enroll Student</button>
                    </form>
                @endif
            </div>
        </div> 
    @endif
</div>



@endsection