@extends('layouts.master')

@section('title')
Home
@endsection

@section('content')

<div class="container">
    <!-- Display success message -->
    @if (session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif

    <h3>Your Courses</h3>

    @auth
        @if($courses->isEmpty())
            <p class="text-muted">You are not enrolled in or teaching any courses.</p>
        @else
            <ul class="list-group">
                @foreach ($courses as $course)
                    <li class="list-group-item">
                        <a href="{{ route('courses.show', $course->id) }}">
                            <strong>{{ $course->course_code }}</strong> - {{ $course->course_name }}
                        </a>
                    </li>
                @endforeach
            </ul>
        @endif
    @else
        <p class="text-muted">You need to be logged in to view your courses.</p>
    @endauth
</div>

    <!--display the link for uploading -->
<div class="container">

    <!-- Display the upload link only if the user is logged in and is a teacher -->
    @if (auth()->check() && auth()->user()->is_teacher)
        <div class="mt-4">
            <a href="{{ route('home.uploadForm') }}" class="btn btn-primary">Create New Course</a>
        </div>
    @endif

</div>
@endsection