<div class="container">
    <footer class="d-flex flex-wrap justify-content-between align-items-center py-3 my-4 border-top">
        <p class="col-md-4 mb-0 text-muted">&copy; 2024 Hogwarts - Gryffindor</p>

        <a href="/" class="col-md-4 d-flex align-items-center justify-content-center mb-3 mb-md-0 text-muted text-decoration-none">
            <svg class="bi" width="40" height="32" fill="currentColor">
                <use xlink:href="#bootstrap"/>
            </svg>
        </a>
    </footer>
</div><?php /**PATH /var/www/html/WebAppDev/Assign2/Myapp/resources/views/layouts/footer.blade.php ENDPATH**/ ?>